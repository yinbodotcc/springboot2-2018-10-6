delete from user;
insert into user(id, name) values(1,'John');
insert into user(id, name) values(2,'Smith');
insert into user(id, name) values(3,'Siva');